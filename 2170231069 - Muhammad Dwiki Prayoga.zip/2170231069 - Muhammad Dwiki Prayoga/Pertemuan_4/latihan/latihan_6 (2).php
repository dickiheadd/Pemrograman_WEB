<body style="background-color: #EFF5F5;">

<?php

echo "<center>Nama :".$_POST['nama']."</center><br>";

echo "<center>Email :".$_POST['email']."</center><br>";

?>    

</body>