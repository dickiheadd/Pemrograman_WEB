<?php   

$angka=90;

?>