<body style="background-color: #EFF5F5;">

<?php

setcookie("variable_cookies","ini adalah variable cookies",time()+50);

echo "<a href=cekcookies.php>Cek Cookies</a>"

?>    

</body>