<html>
    <head>

        <title>Pemrograman PHP dengan Array</title>

    </head>

    <body style="background-color: #EFF5F5;">

        <?php

        $nama[] = "Muhammad";

        $nama[] = "Dwiki";

        $nama[] = "Prayoga";

        echo $nama[1].$nama[2].$nama[0];

        echo "<br>";

        $jum_array = count($nama);

        echo "jumlah elemen array = ". $jum_array;

        ?>

    </body>
    
</html>