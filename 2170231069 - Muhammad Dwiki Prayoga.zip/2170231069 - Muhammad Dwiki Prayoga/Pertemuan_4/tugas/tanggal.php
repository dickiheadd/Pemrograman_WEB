<html lang="in">

    <head>

        <title>Tanggal </title>

    </head>

    <body style="background-color: #EFF5F5;">

        <?php

        date_default_timezone_set('Asia/Jakarta');

        echo date("l, j F Y, H:i:s a"); ?>
        
    </body>

</html>